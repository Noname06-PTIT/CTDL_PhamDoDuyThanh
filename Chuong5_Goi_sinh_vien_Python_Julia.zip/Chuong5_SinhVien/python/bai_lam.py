"""Hoàn thành bốn hàm. Giữ nguyên tên, tham số và quy ước trả về."""
from cau_truc import DSLK, NganXep, HangDoiVong, so_nguyen
BAN = "Sinh viên"


def dem_gia_tri(L: DSLK, x: int) -> int:
    """Đếm nút có gt == x; duyệt bằng ke, không thay đổi L."""
    # Bài 1: trả về số lần xuất hiện; danh sách rỗng trả về 0.
    raise NotImplementedError("Bài 1: cần hoàn thành dem_gia_tri trong python/bai_lam.py.")


def xoa_tat_ca(L: DSLK, x: int) -> int:
    """Xoá mọi nút có gt == x; trả số nút xoá, cập nhật n đúng."""
    # Bài 2: một lượt duyệt; không tạo lại danh sách hoặc cấp phát nút mới.
    raise NotImplementedError("Bài 2: cần hoàn thành xoa_tat_ca trong python/bai_lam.py.")


def lay_nhieu(s: NganXep, k: int) -> list[int]:
    """Lấy đúng k giá trị theo LIFO; k sai thì báo ValueError trước khi sửa s."""
    # Bài 3: 0 <= k <= số phần tử, k phải là int nhưng không phải bool.
    raise NotImplementedError("Bài 3: cần hoàn thành lay_nhieu trong python/bai_lam.py.")


def xem_k(q: HangDoiVong, k: int) -> list[int]:
    """Đọc k phần tử đầu FIFO; không sửa a, dau, so, n; k sai báo ValueError."""
    # Bài 4: mảng vật lý có thể đã quay vòng. k = 0 phải trả về [].
    raise NotImplementedError("Bài 4: cần hoàn thành xem_k trong python/bai_lam.py.")
